package com.labstyle.darioscrollruler

enum class RulerMarkerType {
    SMALL,
    MEDIUM,
    LARGE,
    OVERFLOW
}