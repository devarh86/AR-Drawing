package com.labstyle.darioscrollruler

interface ScrollRulerListener {
    fun onRulerScrolled(value: Float)
}